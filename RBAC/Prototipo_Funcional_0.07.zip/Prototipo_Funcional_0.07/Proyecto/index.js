// index - CoreData Consulting

// Librerias no tocar
const express    = require('express');
const bodyParser = require('body-parser');
const path       = require('path');
const fileUpload = require('express-fileupload');
const session    = require('express-session');
const app = express();

const modelClientes    = require('./models/clientes.model');
const modelOperaciones = require('./models/operaciones.model');
const modelAlertas     = require('./models/alertas.model');

// Middlewares de autenticacion y roles
const { verificarSesion, verificarRol } = require('./middlewares/auth');

// Notificar el uso de ejs
app.set('view engine', 'ejs');
app.set('views', 'views');

// Configuracion de sesiones
app.use(session({
    secret:            'coredata-pld-secret-2026',
    resave:            false,
    saveUninitialized: false,
    cookie: {
        maxAge:   1000 * 60 * 60 * 8,
        httpOnly: true
    }
}));

// Middleware para archivos
app.use(fileUpload());

// Middleware para parsear datos
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Jala los archivos que esten publicos
app.use(express.static(path.join(__dirname, 'public')));

// Marca la ruta activa y expone el usuario de sesion a todas las vistas
app.use((req, res, next) => {
    res.locals.currentPath = req.path;
    res.locals.usuario     = req.session.usuario || null;
    next();
});

// Conocer el estado del servidor
app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok' });
});

// ----- LOGIN (publico) -----
const rutasLogin = require('./routes/login.routes');
app.use('/login', rutasLogin);

app.get('/', (req, res) => {
    res.redirect('/login');
});

// ----- PORTAL CLIENTE (solo rol Cliente) -----
const rutasPortal = require('./routes/portal.routes');
app.use('/portal', verificarSesion, rutasPortal);

// ----- DASHBOARD (Oficial y Analista) -----
app.get('/dashboard', verificarSesion, verificarRol('Oficial de Cumplimiento', 'Analista'), (req, res) => {
    res.render('dashboard', { mensaje: req.query.mensaje || null });
});

// API para los contadores del dashboard
app.get('/api/dashboard', verificarSesion, verificarRol('Oficial de Cumplimiento', 'Analista'), async (req, res) => {
    try {
        const resultadoClientes    = await modelClientes.ObtenerClientesLista();
        const resultadoOperaciones = await modelOperaciones.ObtenerOperaciones();
        const resultadoAlertas     = await modelAlertas.ObtenerAlertas();

        const clientes    = resultadoClientes.clientes || [];
        const operaciones = resultadoOperaciones.operaciones || [];
        const alertas     = resultadoAlertas.alertas || [];

        const alertasRecientes = alertas.slice(0, 5).map(function(a) {
            return {
                descripcion: a.regla || ('Operacion #' + (a.idoperacion || '')),
                nivel:       a.nivel || '',
                estatus:     a.estatus || '',
                fecha:       a.fecha || ''
            };
        });

        const distribucionRiesgo = ['Bajo', 'Medio', 'Alto'].map(function(nivel) {
            return {
                nivel:    nivel,
                cantidad: clientes.filter(function(c) { return c.nivelriesgo === nivel; }).length
            };
        });

        res.json({
            totalClientes:          clientes.length,
            totalOperaciones:       operaciones.length,
            totalAlertasPendientes: alertas.filter(function(a) { return a.estatus !== 'Resuelta'; }).length,
            totalReportesListos:    0,
            alertasRecientes:       alertasRecientes,
            distribucionRiesgo:     distribucionRiesgo
        });
    } catch (error) {
        res.json({
            totalClientes: 0, totalOperaciones: 0,
            totalAlertasPendientes: 0, totalReportesListos: 0,
            alertasRecientes: [], distribucionRiesgo: []
        });
    }
});

// ----- CLIENTES (Oficial y Analista) -----
const rutasClientes = require('./routes/clientes.routes');
app.use('/clientes', verificarSesion, verificarRol('Oficial de Cumplimiento', 'Analista'), rutasClientes);

// ----- OPERACIONES (Oficial y Analista) -----
const rutasOperaciones = require('./routes/operaciones.routes');
app.use('/operaciones', verificarSesion, verificarRol('Oficial de Cumplimiento', 'Analista'), rutasOperaciones);

// ----- ALERTAS (ver: Oficial y Analista | resolver: solo Oficial, definido en la ruta) -----
const rutasAlertas = require('./routes/alertas.routes');
app.use('/alertas', verificarSesion, verificarRol('Oficial de Cumplimiento', 'Analista'), rutasAlertas);

// ----- CONTRATOS (Oficial y Analista) -----
const rutasContratos = require('./routes/contratos.routes');
app.use('/contratos', verificarSesion, verificarRol('Oficial de Cumplimiento', 'Analista'), rutasContratos);

// ----- REPORTES (solo Oficial) -----
const rutasReportes = require('./routes/reportes.routes');
app.use('/reportes', verificarSesion, verificarRol('Oficial de Cumplimiento'), rutasReportes);

// ----- ADMIN (solo Oficial) -----
const rutasAdmin = require('./routes/admin.routes');
app.use('/admin', verificarSesion, verificarRol('Oficial de Cumplimiento'), rutasAdmin);

// ----- REGLAS (solo Oficial) -----
const rutasReglas = require('./routes/reglas.routes');
app.use('/reglas', verificarSesion, verificarRol('Oficial de Cumplimiento'), rutasReglas);

// ----- HISTORIAL (solo Oficial) -----
const rutasHistorial = require('./routes/historial.routes');
app.use('/historial', verificarSesion, verificarRol('Oficial de Cumplimiento'), rutasHistorial);

// ----- REPORTES INTERNOS (todos los autenticados) -----
const rutasReportesInternos = require('./routes/reportes_internos.routes');
app.use('/reportes-internos', verificarSesion, rutasReportesInternos);

// Manejador de errores global
app.use((error, req, res, next) => {
    console.error(error.message);

    if (req.path.includes('/api/')) {
        res.status(503).json({
            msg:     'No fue posible consultar la base de datos',
            detalle: error.message
        });
        return;
    }

    next(error);
});

// Inicia el servidor en el host 3000
const server = app.listen(3000, () => {
    console.log('-> http://localhost:3000');
});

process.on('SIGINT', () => {
    server.close(() => {
        process.exit(0);
    });
});
