// Controller login y autenticacion - tres roles: Oficial de Cumplimiento, Analista, Cliente

const modelLogin = require('../models/login.model');
const supabase   = require('../config/supabase');

// Usuario de acceso rapido para demo/pruebas
const usuarioDemo = {
    correo:   'demo@sofom.mx',
    password: 'demo123',
    nombre:   'Usuario Demo',
    rol:      'Oficial de Cumplimiento'
};

// Vista de login
module.exports.VistaLogin = async (req, res) => {
    if (req.session && req.session.usuario) {
        return res.redirect('/dashboard');
    }
    res.render('./login/login', {
        usuarioDemo: usuarioDemo,
        mensaje:     req.query.mensaje || null
    });
};

// Procesar login
module.exports.ProcesarLogin = async (req, res) => {
    const { correo, password } = req.body;

    // Acceso rapido demo - rol Oficial de Cumplimiento
    if (correo === usuarioDemo.correo && password === usuarioDemo.password) {
        req.session.usuario = {
            id:        0,
            nombre:    usuarioDemo.nombre,
            correo:    usuarioDemo.correo,
            rol:       usuarioDemo.rol,
            idcliente: null
        };
        return res.redirect('/dashboard');
    }

    try {
        const usuario = await modelLogin.ValidarCredenciales(correo, password);

        if (!usuario) {
            return res.redirect('/login?mensaje=Datos incorrectos. Verifica tu correo y contrasena.');
        }

        // Si el rol es Cliente, buscar su idcliente por correo en la tabla cliente
        let idcliente = null;
        if (usuario.rol === 'Cliente') {
            const { data: clienteData } = await supabase
                .from('cliente')
                .select('idcliente')
                .eq('correoelectronico', correo)
                .limit(1);

            if (clienteData && clienteData.length > 0) {
                idcliente = clienteData[0].idcliente;
            }
        }

        req.session.usuario = {
            id:        usuario.id,
            nombre:    usuario.nombre,
            correo:    usuario.correo,
            rol:       usuario.rol,
            idcliente: idcliente
        };

        // Los clientes van a su portal, los demas al dashboard
        if (usuario.rol === 'Cliente') {
            return res.redirect('/portal/mi-expediente');
        }

        res.redirect('/dashboard');

    } catch (error) {
        res.redirect('/login?mensaje=No fue posible conectar con la base de datos. Usa el acceso rapido.');
    }
};

// Logout: destruye la sesion
module.exports.Logout = async (req, res) => {
    req.session.destroy(function(err) {
        res.redirect('/login');
    });
};

// Vista de registro (sin uso por ahora)
module.exports.VistaRegistro = async (req, res) => {
    res.render('./login/login', {
        usuarioDemo: usuarioDemo,
        mensaje:     null
    });
};

module.exports.ProcesarRegistro = async (req, res) => {
    res.redirect('/login');
};
