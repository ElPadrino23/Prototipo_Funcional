// Portal del cliente - solo ve su propio expediente, operaciones y contratos

const supabase = require('../config/supabase');

// Mi expediente
module.exports.MiExpediente = async (req, res) => {
    try {
        const idcliente = req.session.usuario.idcliente;

        if (!idcliente) {
            return res.redirect('/login?mensaje=No se encontro tu expediente. Contacta a tu analista.');
        }

        const [resCliente, resDocs] = await Promise.all([
            supabase.from('cliente').select('*').eq('idcliente', idcliente).single(),
            supabase.from('documentocliente').select('*').eq('idcliente', idcliente)
        ]);

        res.render('./portal/mi_expediente', {
            cliente:    resCliente.data || null,
            documentos: resDocs.data   || []
        });
    } catch (error) {
        res.status(500).send('Error: ' + error.message);
    }
};

// Mis operaciones
module.exports.MisOperaciones = async (req, res) => {
    try {
        const idcliente = req.session.usuario.idcliente;

        if (!idcliente) {
            return res.redirect('/login?mensaje=No se encontro tu expediente.');
        }

        const { data: operaciones } = await supabase
            .from('operacion')
            .select('*')
            .eq('idcliente', idcliente)
            .order('idoperacion', { ascending: false });

        res.render('./portal/mis_operaciones', {
            operaciones: operaciones || []
        });
    } catch (error) {
        res.status(500).send('Error: ' + error.message);
    }
};

// Mis contratos
module.exports.MisContratos = async (req, res) => {
    try {
        const idcliente = req.session.usuario.idcliente;

        if (!idcliente) {
            return res.redirect('/login?mensaje=No se encontro tu expediente.');
        }

        const { data: contratos } = await supabase
            .from('contrato')
            .select('*')
            .eq('idcliente', idcliente)
            .order('idcontrato', { ascending: false });

        res.render('./portal/mis_contratos', {
            contratos: contratos || []
        });
    } catch (error) {
        res.status(500).send('Error: ' + error.message);
    }
};
