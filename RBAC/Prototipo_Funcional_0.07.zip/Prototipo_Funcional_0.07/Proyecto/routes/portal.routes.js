// Rutas del portal del cliente - solo accesible con rol Cliente

const express    = require('express');
const router     = express.Router();
const controller = require('../controllers/portal.controller');
const { verificarRol } = require('../middlewares/auth');

// Solo el rol Cliente puede entrar aqui
router.use(verificarRol('Cliente'));

router.get('/mi-expediente',   controller.MiExpediente);
router.get('/mis-operaciones', controller.MisOperaciones);
router.get('/mis-contratos',   controller.MisContratos);

module.exports = router;
