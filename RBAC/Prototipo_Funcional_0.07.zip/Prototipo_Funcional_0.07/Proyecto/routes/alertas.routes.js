// Rutas para las alertas

const express           = require('express');
const router            = express.Router();
const controllerAlertas = require('../controllers/alertas.controller');
const { verificarRol }  = require('../middlewares/auth');

// Mostrar las alertas (Oficial y Analista)
router.get('/lista', controllerAlertas.ObtenerAlertas);

// API JSON para el frontend
router.get('/api/lista', controllerAlertas.ApiListaAlertas);

// Detalle de alerta
router.get('/detalle', controllerAlertas.VistaDetalleAlerta);

// Resolver / cambiar estatus: solo Oficial de Cumplimiento (RN-05)
router.post('/api/resolver',     verificarRol('Oficial de Cumplimiento'), controllerAlertas.ApiResolverAlerta);
router.post('/api/estatus',      verificarRol('Oficial de Cumplimiento'), controllerAlertas.ApiCambiarEstatus);
router.post('/resolver-detalle', verificarRol('Oficial de Cumplimiento'), controllerAlertas.ProcesarResolucion);
router.get('/resolver',          verificarRol('Oficial de Cumplimiento'), controllerAlertas.VistaResolverAlerta);
router.post('/resolver',         verificarRol('Oficial de Cumplimiento'), controllerAlertas.ResolverAlerta);

module.exports = router;
